import { Map } from 'immutable'
import { LOGIN_REQUEST, IS_LOGGING, LOGGED, LOGIN_FAILED } from '../actions/Session'

const initialState = Map({
  data: null,
  isLogging: false,
  logged: false,
  error: null
})

const reducer = (state = initialState, action) => {
  switch (action.type){
    case LOGIN_REQUEST:
      return initialState

    case IS_LOGGING:
      return state.merge({ isLogging: true })

    case LOGGED:
      const data = action.payload
      return state.merge({ isLogging: false, logged: true, data })

    case LOGIN_FAILED:
      return state.merge({
        isLogging: false,
        error: action.payload
      })

    default:
       return state
  }
}

export default reducer
