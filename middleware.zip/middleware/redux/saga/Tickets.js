import { call, put, select } from 'redux-saga/effects'

import { isFetching, fetched, fetchFailed, fetch } from '../actions/Tickets'
import api from '../../api'
import { getSession } from '../selectors'


export function * dataSaga() {
    yield put(isFetching())
    const store = yield select()
    const session = getSession(store)
    try {
        var data = {
          documents: [],
          tasks: []
        }
        if(session.roles.include('sightning')){
          documentsResponse = yield call(api.fetchDocuments)
          data.documents = documentsResponse.data
        }
        if(session.roles.include('sightning')){
          tasksResponse = yield call(api.fetchTasks)
          data.tasks = tasksResponse.data
        }
        yield put(fetched(data))
    }
    catch(error) {
        yield put(fetchFailed(error))
    }
}
