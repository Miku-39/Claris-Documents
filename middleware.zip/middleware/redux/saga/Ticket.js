import { call, put } from 'redux-saga/effects'

import * as actions from '../actions/Ticket'
import api from '../../api'


export function * updateTicketSaga(action) {
    yield put(actions.isUpdating())
    try {
        const response = yield call(api.updateTicketStatus, action.payload)
        yield put(actions.updated())
    }
    catch(error) {
        yield put(actions.updateFailed(error))
    }
}
